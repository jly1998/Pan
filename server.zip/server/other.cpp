#include "mysql_select.h"

/**********************************************************
func:   ��õ�ǰʱ�� ������-ʱ����
input:  void
output: NowDate
*********************************************************/

NowDate getTime()
{
    time_t timep;
    time(&timep);
    NowDate date;

    strftime(date.tmp0, sizeof(date.tmp0), "%Y-%m-%d", localtime(&timep));
    strftime(date.tmp1, sizeof(date.tmp1), "%H:%M:%S", localtime(&timep));

    return date;
}

//��ú���������
long getCurrentTimeMsec()
{
    int i = 0;
    long msec = 0;
    char str[20] = {0};
    struct timeval stuCurrentTime;

    gettimeofday(&stuCurrentTime, NULL);
    sprintf(str, "%ld%03ld", stuCurrentTime.tv_sec, (stuCurrentTime.tv_usec) / 1000);

    for (i = 0; i < strlen(str); i++)
    {
        msec = msec * 10 + (str[i] - '0');
    }
    return msec;
}
