#include <stdbool.h>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <string>
#include <errno.h>
#include <fcntl.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <netinet/tcp.h>
#include <netdb.h>
#include <sys/prctl.h>
#include <sys/stat.h>
#include "mysql_select.h"

//接受缓存区大小
#define BUFSIZE 1024
#define LINEBUF 1024

#define _BACKLOG_ 20

//数据长度限制
#define USER_LEN 45
#define PSWD_LEN 45

//数据库密码
#define DBPASSWD "10020119"
#define DBNAME "test"

//临时文件名
#define ReqFileName ".request.txt"

//数据存储根目录
#define DataRoot "./data"

typedef enum
{
    Error,       //错误
    SignUp,      //注册
    SignIn,      //登录
    Upload_req,  //上传文件
    Upload_data, //文件数据
    Download,    //下载文件
    Delete,      //删除文件
    GetDir,      //获取目录结构
    Move,
    Copy,
} request_type;  //请求的类型

typedef enum
{
    other,
    json,       //application/x-www-form-urlencoded
    formdata,   //multipart/form-data
} content_type; //请求的contenttype

/*************tcp****************/
/**********
网盘客户端主进程
_port   端口号（字符串
**********/
int Disk_server(char *_port);

/**********
建立监听socket，返回描述符
_port   端口号（字符串
**********/
int S_CreateListenSock(char *_port);

/**********
接受连接
listen_sock     监听socket
Maxfd           当前最大socket
**********/
int S_AcConncs(int listen_sock, int &Maxfd);

/**********
将socket设置为非阻塞的
iSock   套接字描述符
**********/
int SetNonBlock(int iSock);

/**********
请求处理函数
responseBody     回复正文
**********/
int DealRequest(string &responseBody);

/**********
为上传文件夹建立新目录
path            待建目录的根目录
RelativePath    某文件的相对路径
user            用户名
**********/
int CreateRelativePath(string path, string RelativePath, string user);

/*************http协议处理****************/

/**********
获取请求正文，返回请求内容的长度(>=0); 若小于0说明出错, body的值不可信
request     完整的请求
body        去除头部后的正文部分
ctype       该请求的contenttype
boundary    若请求为formdata，该值有效，为formdata的boundary
**********/
int GetRequestBody(int req_fd, char *&body, content_type &ctype, string &boundary);

/**********
处理json，返回枚举类型request_type
request_body    去除头部后的正文部分
data_begin      若类型正确，data_begin指向请求类型后的数据起始地址；若类型错误，该值不可信
**********/
request_type RequestType(char *request_body, char *&data_begin, int &ContentLen);

/**********
处理用户注册登录的数据，若返回值不是_SUCCESS则username passwd的值不可信
data_begin      请求类型后的数据起始地址
username        用户int名，需要在调用本函数前申请好长度为USERLEN+1的空间
passwd          密码，需要在调用本函数前申请好长度为PSWDLEN+1的空间
**********/
int GetUserPasswd(char *data_begin, char *username, char *passwd);

/**********
处理待传输文件的详细信息，返回路径id，若返回_ERROR，则file_info结果不可信
data_begin      指向请求类型后的数据起始地址
file_info       文件信息
**********/
int GetFileformat(char *&data_begin, file_format &file_info);

/**********
将目录编号转换为路径字符串
DirNum          目录在数据库中的编号
num             目录结构表的大小
Cur_Dir         用户当前目录结构
**********/
string TransPath(int DirNum, int num, file_format *Cur_Dir);

/**********
处理上传到服务器的文件数据，返回收到的块编号，若<0则错误
data_begin      请求类型后的数据起始地址
boundary        boundary
DataLen         收到的数据的长度
file_data       文件数据的起始地址，无需申请空间，需要释放
file_info       文件信息，结构体中MD5和chunk总数有意义
**********/
int GetFileData(char *&data_begin, string boundary, int &DataLen, char *&file_data, file_format &file_info);

/**********
获取用户的目录，返回string为json字符串
file      数组的头指针
**********/
string GetFileTree(int num, file_format *file);

/**********
获取用户名，若返回值不是_SUCCESS则username的值不可信
data_begin      请求类型后的数据起始地址
username        用户名
**********/
int GetUsername(char *data_begin, string &username);

/**********
处理用户删除文件的数据，若返回值不是_SUCCESS则fileid的值不可信
data_begin      请求类型后的数据起始地址
fileid          文件id int型
**********/
int Getfileid(char *data_begin, int &fileid);

/**********
处理用户移动/复制文件/夹的数据，若返回值不是_SUCCESS则from_id，to_id的值不可信
data_begin      请求类型后的数据起始地址
from_id         待移动/删除的文件id
to_id           将移动/删除至的文件夹id
**********/
int Getfromtoid(char *data_begin, int &from_id, int &to_id);

/*************other****************/
/**********
发送响应报文
socket  目的socket
code    状态码
Status  数据库操作的返回值
body    响应报文的内容，若无内容则body为NULL
**********/
int SendResponse(int socket, int code, int Status, char *body);

/**********
设置回复报文的正文内容
Total       总包数
Uploaded    服务器中已有包数
No          下个包的序号，若已传输结束则置0
**********/
string SetResponseBody(int Total, int Uploaded, int No);

/**********
read方式获取一整行
fd  文件描述符
linebuf 结果
**********/
int MyGetline(int fd, string &linebuf);

/**********
存储当前块
ChunkNo         Chunk号
DataLen         收到的数据的长度
file_data       文件数据的起始地址，无需申请空间，需要释放
file_path       文件路径
**********/
int SaveFile(const int ChunkNo, const int DataLen, const char *file_data, const string file_path, const string file_name);

/**********
建立新目录
path            待建目录的根目录
dirName         待建目录名
**********/
int CreateDir(const char *path, const char *dirName);
